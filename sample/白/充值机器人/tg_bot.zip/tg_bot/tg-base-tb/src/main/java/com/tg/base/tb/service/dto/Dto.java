package com.tg.base.tb.service.dto;

public class Dto {
}
