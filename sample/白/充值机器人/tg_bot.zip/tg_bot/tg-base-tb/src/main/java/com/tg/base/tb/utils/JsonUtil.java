package com.tg.base.tb.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * json工具类
 */
public class JsonUtil {
    public static ObjectMapper objectMapper = new ObjectMapper();
}
