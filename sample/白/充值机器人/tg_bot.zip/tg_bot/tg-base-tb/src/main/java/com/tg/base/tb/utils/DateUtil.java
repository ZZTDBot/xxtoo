package com.tg.base.tb.utils;

import java.text.SimpleDateFormat;

/**
 * 日期工具类
 */
public class DateUtil {
    //
    public static final String FORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

    public static final String FORMAT_YYYY_MM_DD_HH_MM_SS1 = "yyyyMMddHHmmss";
    public static final String FORMAT_YYYYMMDD = "yyyyMMdd";
    public static final String FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String FORMAT_HH_MM_SS = "HH:mm:ss";





    public static final SimpleDateFormat xiaoShiSimf = new SimpleDateFormat("HH:mm:ss");
}
