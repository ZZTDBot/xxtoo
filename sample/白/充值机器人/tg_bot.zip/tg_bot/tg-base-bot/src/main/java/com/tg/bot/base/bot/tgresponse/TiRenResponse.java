package com.game.qs.bot.tgresponse;

import lombok.Data;

/**
 * 踢人的响应实体类
 */
@Data
public class TiRenResponse {
    //{"ok":true,"result":true}
    private Boolean ok;
    private Boolean result;
}
