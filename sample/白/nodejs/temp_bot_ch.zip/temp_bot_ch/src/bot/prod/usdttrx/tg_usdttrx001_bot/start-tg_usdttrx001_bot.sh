#bin/bash
nohup node tg_usdttrx001_bot.js > tg_usdttrx001_bot.out 2>&1 &