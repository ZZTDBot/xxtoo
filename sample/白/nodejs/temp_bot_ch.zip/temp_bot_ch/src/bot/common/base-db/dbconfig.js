const host = "localhost";
const port = "3306";
const user = "root";
const password = "root";

module.exports = {
    host,port,user,password
}