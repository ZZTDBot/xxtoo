//db配置
const dbconfig = require('./dbconfig');
//db工具
const dbutils = require('./dbutils');

module.exports = {
    dbconfig,
    dbutils
}