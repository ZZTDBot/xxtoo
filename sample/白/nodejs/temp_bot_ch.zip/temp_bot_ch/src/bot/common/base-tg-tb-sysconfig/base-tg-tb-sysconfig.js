//引入操作数据库Dao类
const TbSysConfigDao = require('./dao/TbSysConfigDao');

module.exports = {
    TbSysConfigDao
}