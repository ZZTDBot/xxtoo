const a = 4,
  b = 5;
const c = a * b;
console.log("c = " + c);
