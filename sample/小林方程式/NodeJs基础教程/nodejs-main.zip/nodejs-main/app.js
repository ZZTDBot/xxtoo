console.log("codewithlarry share with you the full-stack skillsets");
